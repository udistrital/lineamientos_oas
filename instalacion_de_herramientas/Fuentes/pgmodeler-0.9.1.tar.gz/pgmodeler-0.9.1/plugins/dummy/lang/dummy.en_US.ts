<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>DummyPlugin</name>
    <message>
        <location filename="../src/dummyplugin.cpp" line="21"/>
        <source>Dummy Plugin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/dummyplugin.cpp" line="27"/>
        <source>Plugin Carregado!</source>
        <translation>Plugin Loaded!</translation>
    </message>
    <message>
        <location filename="../src/dummyplugin.cpp" line="28"/>
        <source>Plugin carregado com sucesso! Para detalhes de como criar seus próprios plugins consulte o arquivo PLUGINS.md</source>
        <translation>Plugin sucessfully loaded! See PLUGINS.md to get details about creating your own plugins</translation>
    </message>
</context>
</TS>
